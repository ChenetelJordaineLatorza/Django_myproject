
from django.http import HttpResponse


def home(request):
    return HttpResponse("<h1>Student Management System!</h1>")
